import React from "react";
import {
  StyleSheet,
  View,
  TextInput,
  SafeAreaView,
  Text,
  TouchableOpacity,
} from "react-native";

export default function App() {
  return (
    <SafeAreaView style={styles.container}>

      <View style={styles.Box}>

      <Text style={{
        fontSize:20,
        color:"green",
        fontWeight:"bold",
        paddingTop:60

      }}
      >MEMBER LOGIN</Text>


      <Text style={{
        color:"grey",
        fontSize:10,
        marginTop:30,
       
      }}
      >Lost your ID or password?</Text>

      <TextInput placeholder="Customer ID"
      style={styles.Input}
      />
      <TextInput placeholder="Password"
      style={styles.Input}/>


      <TouchableOpacity style={styles.button}>Login</TouchableOpacity>



      </View>





      <Text 
      style={{
        fontSize:17,
        fontWeight:"bold",
        color:"#fff",
        marginTop:20
      }}>
        Don't have an account? Open an account
      </Text>
      
    </SafeAreaView>
  );
}



const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "green",
    alignItems:"center",
    justifyContent:"center"

    
  },

  Box:{
    backgroundColor:"white",
    width:450,
    height:400,
    paddingLeft:50,
   

  },
  Input:{
    
    borderBottomColor:"grey",
    color:"grey",
    borderBottomWidth:2,
    width:300,
    marginTop:20,
    paddingLeft:20
  },
  button:{
    width: 300,
    backgroundColor: "green",
    textAlign: "center",
    fontSize: 20,
    color: "#fff",
    height: 50,
    justifyContent: "center",
    marginTop:50,
  
    fontFamily: "Calibri",
  },
  
 
 
});







